matpower-extras
===============

MATPOWER Extras - contributed and/or unsupported MATPOWER-related code

See Appendix E of the [MATPOWER User's Manual][1] for details.

To install, simply place the contents of this repository in a directory
named `extras` inside the MATPOWER install directory and re-run
`install_matpower`.

---

[1]: https://matpower.org/docs/MATPOWER-manual.pdf
